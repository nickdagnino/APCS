/**
 * HONOR PLEDGE: All work here is honestly obtained and is my own. Nicholas Dagnino
 * @author NicholasDagnino23
 * Date of Completion:  1/8/2021
 * Assignment:  Chapter 11 - ArrayList
 * 
 * Attribution: JMAP Textbook
 * 
 * General Description:   This project demonstrates my ability to design the ArrayList class
 * 
 * 
 * Advanced:  NONE
 * 
 * Errata:  Remove() does not work
 *
 */

public class MyArrayList {
	//Declare private fields here needed to represent this class. READ YOUR BOOK!
	private String[] arr;
	private int cap;
	private int size;
	// Creates an empty list with a default initial capacity.
	public MyArrayList() {
		cap = 10;
		size = 0;
		arr = new String[cap];
	}
	// Creates an empty list with a given initial capacity.
	public MyArrayList(int capacity){
		cap = capacity;
		size = 0;
		arr = new String[cap];
	}
	// Returns the number of elements currently stored in the list.
	public int size(){
		return size;
	}
	// Returns true if the list is empty, false otherwise.
	public boolean isEmpty(){
		return size == 0;
	}
	//Appends value to the end of the logical list; returns true. Grows list if
	// needed.
	public void add(String val){

		growList();

		for(int i = 0; i < arr.length-1; i++) {
			if(arr[i] == null) {
				arr[i] = val;
				size++;
				break;

			}

		}
	}
	//Inserts val into the i-th position of the logical list; shifts as required.
	//Grows list as needed.
	public void add(int i, String val){

		growList();

		for(int j = arr.length-1; j > i ; j--) {
			arr[j] = arr[j-1];
		}
		arr[i] = val;
		size++;

	}
	//Returns the value of the i-th element
	public String get(int i){
		if(i >= arr.length) {
			throw new ArrayIndexOutOfBoundsException("Invalid");
		}
		return arr[i];
	}
	//Replaces the i-th value, with the given value; returns the old value
	public String set(int i, String val){
		if(i >= arr.length) {
			throw new ArrayIndexOutOfBoundsException("Invalid");
		}
		arr[i] = val;
		return arr[i];
	}
	//Removes the i-th element from the logical list and returns its value; shifts
	// as required.
	public String remove(int i){
		if(i >= arr.length) {
			throw new ArrayIndexOutOfBoundsException("Invalid");
		}
		for(int j = i; j > arr.length-1; j++) {
			setSafe(j, arr[j+1]);
		}
		size--;
		return arr[i];
	}
	private void setSafe(int i, String val) {
		arr[i] = val;
	}
	//Displays the contents of this class in the following format: �[elt0, elt1, elt2, ...]�
	public String toString() {
		String out = "[";
		if(size == 0) {
			out += "]";
			return out;
		}
		for(int i = 0; i < size; i++) {
			out += arr[i] + ", ";
		}
		out = out.substring(0, out.length()-2);
		out += "]";
		return out;
	}
	//Helper method that can be activated to double the capacity of a full list,
	//transfer all values to their corresponding positions and replace the original
	//list by the new doubled-size list. You may use this method, even if you
	//cannot code it correctly.
	private void growList(){
		String[] arr1 = new String[arr.length*2];
		for(int i = 0; i < size; i++) {
			arr1[i] = arr[i];
		}
		arr = arr1;
	}
}