/**
 * HONOR PLEDGE: All work here is honestly obtained and is my own. Nicholas Dagnino
 * @author NicholasDagnino23
 * Date of Completion:  1/9/2021
 * Assignment:  Chapter 11 - Ex. 5, 6, 7, 10, 13
 * 
 * Attribution: JMAP Textbook
 * 
 * General Description:   This project demonstrates my ability to use and manipulate the ArrayList class
 * 
 * 
 * Advanced:  NONE
 * 
 * Errata:  NONE
 *
 */

import java.util.ArrayList;
import java.util.List;

public class Ch11_HW {

	/**
	 * Problem #5 - reverse an ArrayList without changing the original ArrayList
	 * @param list
	 * @return reverse
	 */
	public static ArrayList<String> problem5(ArrayList<String> list){
		ArrayList<String> reverse = new ArrayList<String>(list.size());
		for(int i = list.size()-1; i >= 0; i--) {
			reverse.add(list.get(i));
		}
		return reverse;
	}

	/**
	 * Problem #6 - remove the smallest element in the list
	 * @param list
	 */
	public static void problem6(ArrayList<Integer> list) {
		if(list.size() == 0) return; 

		Integer temp = list.get(0);
		int index = 0;
		for(int i = list.size()-1; i > 0; i--) {
			if(temp.compareTo(list.get(i)) > 0) {
				temp = list.get(i);
				index = i;
			}
		}
		list.remove(index);
	}

	/**
	 * Problem #7 - remove an object from list1 if it is in list2
	 * @param list1
	 * @param list2
	 */
	public static void filter(ArrayList<Object> list1, ArrayList<Object> list2) {
		for(Object obj : list2) {
			int i = 0;
			while(i < list1.size()) {
				if(list1.get(i) == obj) {
					list1.remove(i);
				}
				else {
					i++;
				}
			}
		}
	}

	/**
	 * Problem #10 - remove consecutive duplicates so that only one of the same letters remains
	 * @param list
	 */
	public static void removeConsecutiveDuplicates(ArrayList<String> list) {
		for(int i = 1; i < list.size(); i++){
			if(list.get(i-1).equals(list.get(i))) {
				list.remove(i-1);
				i--;
			}
		}
	}

	/**
	 * Problem #13 - places the object (String) in to a "buckets if the first letter matches the letter of the bucket
	 * @param words
	 * @return buckets
	 */
	private static String abc = "abcdefghijklmnopqrstuvwxyz";
	public static ArrayList<ArrayList<String>> problem13(List<String> words){
		ArrayList<ArrayList<String>> buckets = new ArrayList<ArrayList<String>>(26); //size 0
		for(int i = 0; i < 26; i++) {
			buckets.add(new ArrayList<String>());
		}

		for(String word : words) {
			char firstLetter = word.charAt(0);
			int location = abc.indexOf(firstLetter);
			buckets.get(location).add(word);

		}
		return buckets;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Problem #5 - reverse an ArrayList without changing the original ArrayList
		ArrayList<String> stringList = new ArrayList<String>();
		stringList.add("The");
		stringList.add("Nicholas");
		stringList.add("Dagnino");
		System.out.println("The original list is " + stringList);
		System.out.println("The reversed list is " + problem5(stringList));

		//Problem #6 - remove the smallest element in the list
		ArrayList<Integer> intList = new ArrayList<Integer>();
		intList.add(1);
		intList.add(2);
		intList.add(3);
		intList.add(4);
		intList.add(5);
		System.out.println("The original list is " + intList);
		problem6(intList);
		System.out.println("The list with the smallest element removed is " + intList);

		//Problem #7 - remove an object from list1 if it is in list2
		ArrayList<Object> list1 = new ArrayList<Object>();
		list1.add("the");
		list1.add("very");
		list1.add("happy");
		list1.add("children");
		list1.add("ate");
		list1.add("candy");
		ArrayList<Object> list2 = new ArrayList<Object>();
		list2.add("the");
		list2.add("sad");
		list2.add("children");
		list2.add("want");
		list2.add("candy");
		System.out.println("List 1 is " + list1 + "\nList 2 is " + list2);
		filter(list1, list2);
		System.out.println("List 1 is " + list1);

		//Problem #10 - remove consecutive duplicates so that only one of the same letters remains
		ArrayList<String> words = new ArrayList<String>();
		words.add("cat");
		words.add("cat");
		words.add("cat");
		words.add("dog");
		words.add("dog");
		words.add("fish");
		words.add("fish");
		System.out.println("The original list is " + words);
		removeConsecutiveDuplicates(words);
		System.out.println("The list without duplicates is " + words);

		//Problem #13 - places the object (String) in to a "buckets if the first letter matches the letter of the bucket
		ArrayList<String> alpha = new ArrayList<String>();
		alpha.add("apple");
		alpha.add("amazon");
		alpha.add("bog");
		alpha.add("zoom");
		alpha.add("kid");
		alpha.add("hot");
		alpha.add("launch");
		alpha.add("fish");
		alpha.add("yippy");
		alpha.add("jog");
		System.out.println("The original list is " + alpha);
		System.out.println("The sorted list is " + problem13(alpha));
	}

}
