/**
 * 
 */

/**
 * @author NicholasDagnino23
 *
 */
public class TesterClass {

	public static void main(String[] args) {
		MyArrayList list00 = new MyArrayList();
		MyArrayList list01 = new MyArrayList(5);
		
		System.out.println("The size of the array is " + list00.size());
		System.out.println("The size of the array is " + list01.size());
		
		System.out.println("The array is empty: " + list00.isEmpty());
		System.out.println("The array is empty: " + list01.isEmpty());
		
		list00.add("one");
		list01.add("one");
		
		list00.add("two");
		list01.add("two");
		
		System.out.println("The array is empty: " + list00.isEmpty());
		System.out.println("The array is empty: " + list01.isEmpty());
		
		System.out.println(list00.toString());
		System.out.println(list01.toString());
		
		list00.add(1, "three");
		list01.add(1, "three");
		
		System.out.println(list00.toString());
		System.out.println(list01.toString());
		
		System.out.println("The element selected is " + list00.get(1));
		System.out.println("The element selected is " + list01.get(1));
		
		list00.set(0, "four");
		list01.set(0, "four");
		
		System.out.println(list00.toString());
		System.out.println(list01.toString());
		
		
		System.out.println(list00.toString());
		System.out.println(list01.toString());
		
		list00.add("five");
		list01.add("five");
		list00.add("six");
		list01.add("six");
		list00.add("seven");
		list01.add("seven");
		list00.add("eight");
		list01.add("eight");
		list00.add("nine");
		list01.add("nine");
		list00.add("ten");
		list01.add("ten");
		list00.add("eleven");
		list01.add("eleven");
		
		System.out.println(list00.toString());
		System.out.println(list01.toString());
		
		System.out.println(list00.remove(1));
		System.out.println(list01.remove(1));
		
		System.out.println(list00.toString());
		System.out.println(list01.toString());
		
		
		
	}

}
