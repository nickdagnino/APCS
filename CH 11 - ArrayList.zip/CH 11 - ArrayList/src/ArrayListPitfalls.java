import java.util.ArrayList;

public class ArrayListPitfalls {
	//Use of Remove Pitfalls Fixes
	/**
	 * Removes all occurrences of "like" from given list of words.
	 * @param words
	 */
	public static void removeAllLikes(ArrayList<String> words) {
		int i = 0;

		while (i < words.size())
		{
			if ("like".equals(words.get(i)) )
				words.remove(i);
			else
				i++;
		}
	}

	/**
	 * Version 2
	 * Removes all occurrences of "like" from given list of words.
	 * @param words
	 */
	public static void removeAllLikes2(ArrayList<String> words) {
		for (int i = words.size()-1; i>=0; i--) {
			if ("like".equals(words.get(i)) )
				words.remove(i);
		}

	}

	/**
	 * Version 3
	 * Removes all occurrences of "like" from given list of words.
	 * @param words
	 */
	public static void removeAllLikes3(ArrayList<String> words) {
		for (int i = 0; i<words.size(); i++) {
			if ("like".equals(words.get(i)) ) {
				words.remove(i);
				i--;   //a bit "risky" and opaque code as the index variable is adjusted sometimes twice
			}
			//remember that i++ in the third clause of the for loop happens everytime at the bottom of the loop		
		}

	}
}